int main(int argc, char ** argv)
{
#ifdef MULT
    return argc * 42;
#else
    return argc + 42;
#endif
}
